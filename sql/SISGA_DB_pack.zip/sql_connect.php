<?php
$servidor= "localhost";
$usuario= "adminsisga";
$password = "uAdmin2018";
$nombreBD= "sisga";
?>
